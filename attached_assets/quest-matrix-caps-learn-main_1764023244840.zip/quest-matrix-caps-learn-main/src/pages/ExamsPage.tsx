import React, { useState } from "react";
import { FileText, Clock, BookOpen, ChevronRight } from "lucide-react";
import { useNavigate } from "react-router-dom";
import NavBar from "@/components/NavBar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { subjects } from "@/data/curriculum";
import { exams } from "@/data/examData";

const ExamsPage: React.FC = () => {
  const [selectedSubject, setSelectedSubject] = useState<string>("all");
  const navigate = useNavigate();
  
  // Filter exams based on selected subject
  const filteredExams = selectedSubject === "all" 
    ? exams 
    : exams.filter(exam => {
        const subject = subjects.find(s => s.name === exam.subject);
        return subject?.id === selectedSubject;
      });
  
  // Group exams by year
  const examsByYear = filteredExams.reduce((acc, exam) => {
    if (!acc[exam.year]) {
      acc[exam.year] = [];
    }
    acc[exam.year].push(exam);
    return acc;
  }, {} as Record<number, typeof exams>);
  
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy": return "bg-green-100 text-green-800";
      case "Medium": return "bg-yellow-100 text-yellow-800";
      case "Hard": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };
  
  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="sticky top-0 z-10">
        <div className="bg-gradient-to-br from-quest-primary to-quest-purple p-6 text-white">
          <h1 className="text-2xl font-bold mb-2">Exam Papers</h1>
          <p className="opacity-90">Practice with past exam papers to prepare for your tests</p>
        </div>
        
        {/* Subject Filter */}
        <div className="px-4 relative -mt-6 mb-6">
          <Card className="p-4 shadow-sm bg-white">
            <Tabs defaultValue="all" onValueChange={setSelectedSubject}>
              <TabsList className="w-full">
                <TabsTrigger value="all" className="flex-1">All Subjects</TabsTrigger>
                {subjects.map(subject => (
                  <TabsTrigger key={subject.id} value={subject.id} className="flex-1">
                    {subject.name.split(' ')[0]}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          </Card>
        </div>
      </div>
      
      {/* Exam Papers */}
      <div className="p-4 space-y-8">
        {Object.entries(examsByYear)
          .sort(([a], [b]) => Number(b) - Number(a))
          .map(([year, exams]) => (
            <div key={year}>
              <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
                <FileText className="h-5 w-5 text-quest-primary" />
                {year} Papers
              </h2>
              
              <div className="space-y-3">
                {exams
                  .sort((a, b) => a.paper - b.paper)
                  .map(exam => (
                    <Card key={exam.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                          <div className="flex flex-wrap items-center gap-2 mb-2">
                            <h3 className="font-semibold">{exam.subject}</h3>
                            <Badge variant="outline">Paper {exam.paper}</Badge>
                            <Badge className={getDifficultyColor(exam.difficulty)}>
                              {exam.difficulty}
                            </Badge>
                          </div>
                          
                          <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <Clock className="h-4 w-4" />
                              {exam.duration} min
                            </div>
                            <div className="flex items-center gap-1">
                              <BookOpen className="h-4 w-4" />
                              {exam.totalMarks} marks
                            </div>
                          </div>
                        </div>
                        
                        <Button 
                          className="w-full sm:w-auto mt-4"
                          onClick={() => navigate(`/exam/${exam.id}`)}
                        >
                          Start Exam
                          <ChevronRight className="ml-1 h-4 w-4" />
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </div>
          ))}
        
        {Object.keys(examsByYear).length === 0 && (
          <Card className="p-8 text-center">
            <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Exam Papers Available</h3>
            <p className="text-muted-foreground">
              There are no exam papers available for the selected subject.
            </p>
          </Card>
        )}
      </div>
      
      <div className="fixed bottom-0 left-0 right-0">
        <NavBar />
      </div>
    </div>
  );
};

export default ExamsPage;
